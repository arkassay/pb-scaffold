'use strict';

pb.namespace('model');

pb.model = (function() {
  var touch = false;

  return{
    touch: touch
  };
});
